<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="donate"
      v-if="!isLoading"
    >
      <div class="bg-white-2  mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-4 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>
            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/others"
              style="color: #9E9E9E"
            >
              Others
            </router-link>
            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <span style="color: #47B362">
              {{ Others.title }}
            </span>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-4 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>
            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/others"
              style="color: #9E9E9E"
            >
              آخرون
            </router-link>
            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <span style="color: #47B362">
              {{ Others.title_ar }}
            </span>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'en'">
          <div
            class="px-md-0 px-3 mx-auto width-section mt-4"
            style="width:70%"
          >
            <div class="d-flex align-items-center">
              <router-link to="/others">
                <img
                  :src="images.right"
                  width="30px"
                  class="mr-2"
                  style="object-fit: cover;transform: rotate(180deg);"
                />
              </router-link>
              <h2
                class="heade-content_title text-left"
                style="color: #3B3B3B"
              >
                {{ Others.title }}
              </h2>
            </div>
            <span style="color: rgb(177, 177, 177);padding-left: 40px;font-size: 1rem;">
              {{ displayDate(Others.created_at) }}
            </span>
            <div class="row no-gutters">
              <div class="col-12 my-3 px-md-3">
                <img
                  :src="'images/' + Others.photo.filename"
                  width="100%"
                  height="500px"
                  style="border-radius: 5px ;object-fit: cover;"
                />
              </div>

              <div class="col-12 my-3 px-md-5">
                <p class="donate-text  mt-3">
                  {{ Others.content }}
                </p>
              </div>
            </div>
          </div>
        </template>
        <template v-else-if="this.$i18n.locale == 'ar'">
          <div
            class="px-md-0 px-3 mx-auto width-section mt-4 text-right"
            style="width:70%"
          >
            <div class="d-flex align-items-center justify-content-end">
              <h2
                class="heade-content_title text-right"
                style="color: #3B3B3B"
              >
                {{ Others.title_ar }}
              </h2>
              <router-link to="/others">
                <img
                  :src="images.right"
                  width="30px"
                  class="ml-2"
                  style="object-fit: cover;"
                />
              </router-link>
            </div>
            <span style="color: rgb(177, 177, 177);padding-right: 40px;font-size: 1rem;">
              {{ displayDate(Others.created_at) }}
            </span>
            <div class="row no-gutters">
              <div class="col-12 my-3 px-md-3">
                <img
                  :src="'images/' + Others.photo.filename"
                  width="100%"
                  height="500px"
                  style="border-radius: 5px ;object-fit: cover;"
                />
              </div>

              <div class="col-12 my-3 px-md-5">
                <p class="donate-text  mt-3 text-right">
                  {{ Others.content_ar }}
                </p>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        donate: "website/imgs/donate.png",
        altadamon: "website/imgs/altadamon.png",
        yemen_bank: "website/imgs/yemen_bank.png",
        dolar: "website/imgs/dolar.svg",
        yr: "website/imgs/yr.svg",
        right: "website/imgs/chevron-right-solid.svg",
      },
      Others: null,
      isLoading: true,
    };
  },
  methods: {
    displayOthers() {
      let id = this.$route.params.id;
      axios.get("api/webSiteOthers/" + id).then((response) => {
        this.Others = response.data;
        this.isLoading = false;
      });
    },
    displayDate(date) {
      var Dsdate = new Date(date);
      var months = [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
      ];
      var delDateString =
        Dsdate.getFullYear() +
        "/" +
        months[Dsdate.getMonth()] +
        "/" +
        Dsdate.getDate();
      return delDateString;
    },
  },
  computed: {},
  mounted() {
    this.displayOthers();
  },
};
</script>
