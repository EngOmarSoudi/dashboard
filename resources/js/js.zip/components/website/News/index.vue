<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="News"
      v-if="!isLoading"
    >
      <div class="bg-white-2  mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>

            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/news"
              style="color: #47B362"
            >
              News
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>

            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/news"
              style="color: #47B362"
            >
              الاخبار
            </router-link>
          </p>
        </template>
        <div class="px-md-0 px-3 mx-auto width-section mt-4">
          <h2
            class="heade-content_title"
            style="color: #636363"
            data-aos="fade-down"
            data-aos-duration="1000"
          >
            <template v-if="this.$i18n.locale == 'en'">
              News
            </template>
            <template v-else-if="this.$i18n.locale == 'ar'">
              الاخبار
            </template>
          </h2>
          <div
            class="row no-gutters mt-5"
            data-aos="fade-up"
            data-aos-duration="1000"
          >
            <template v-if="this.$i18n.locale == 'en'">
              <div
                class="col-lg-6 col-md-6 my-3 px-md-3 mx-auto d-flex"
                v-for="(item, i) in News"
                :key="i"
              >
                <div
                  class="w-100 row no-gutters h-mobile"
                  style="border-radius: 8px; background-color: #EDFAF1; height: 220px;"
                >
                  <div class="col-md-4 h-100">
                    <img
                      class="card-img-top h-100"
                      :src="'images/' + item.photo.filename"
                      width="100%"
                      style="border-radius: 8px 0 0 8px ;  object-fit: cover "
                    />
                  </div>

                  <div class="text-left p-3 col-md-8">
                    <h5 class="card-title mb-0">
                      {{
                                            item.title
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                    </h5>
                    <p class="card-text mt-2">
                      {{
                                            item.leadingParagraph
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                    </p>
                    <router-link
                      :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                      class="url_more "
                    >
                      Read more
                      <img
                        :src="images.right"
                        width="25px"
                        class="ml-2"
                        style=" object-fit: cover "
                      />
                    </router-link>
                  </div>
                </div>
              </div>
            </template>
            <template v-else-if="this.$i18n.locale == 'ar'">
              <div
                class="col-lg-6 col-md-6  my-3 px-md-3 mx-auto d-flex"
                v-for="(item, i) in News"
                :key="i"
              >
                <div
                  class="w-100 row no-gutters h-mobile"
                  style="border-radius: 8px; background-color: #EDFAF1; height: 220px;"
                >
                  <div class="text-right p-3 col-md-8 order-md-1 order-2">
                    <h5
                      class="card-title mb-0"
                      dir="rtl"
                    >
                      {{
                                            item.title_ar
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                    </h5>
                    <p
                      class="card-text mt-2"
                      dir="rtl"
                    >
                      {{
                                            item.leadingParagraph_ar
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                    </p>
                    <router-link
                      :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                      class="url_more "
                      style="left: 15px;right: auto;"
                    >
                      <img
                        :src="images.right"
                        width="25px"
                        class="mr-2"
                        style="object-fit: cover;transform: rotate(180deg);"
                      />
                      اقرأ أكثر
                    </router-link>
                  </div>
                  <div class="col-md-4 h-100 order-md-2 order-1">
                    <img
                      class="card-img-top h-100"
                      :src="'images/' + item.photo.filename"
                      width="100%"
                      style="border-radius:  0 8px 8px 0 ;  object-fit: cover "
                    />
                  </div>
                </div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        right: "website/imgs/chevron-right-solid.svg",
      },
      News: [],
      isLoading: true,
    };
  },
  methods: {
    displayNews() {
      axios.get("api/webSiteNews").then((response) => {
        this.News = response.data;
        this.isLoading = false;
      });
    },
  },
  mounted() {
    this.displayNews();
  },
};
</script>
