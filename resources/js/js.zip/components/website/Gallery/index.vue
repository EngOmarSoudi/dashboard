<template>
 <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div class="donate" v-if="!isLoading">
        <div class="bg-white-2 px-0  mt-5">
            <template v-if="this.$i18n.locale == 'en'">
                <p class="heade-content_title text-left px-md-4 px-2 mt-0">
                    <router-link to="/" style="color: #9E9E9E">
                        Home
                    </router-link>
                    <svg
                        class="mx-1"
                        xmlns="http://www.w3.org/2000/svg"
                        width="8.947"
                        height="15"
                        viewBox="0 0 8.947 15"
                    >
                        <path
                            id="icons8_forward"
                            d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                            transform="translate(-8.939 -6.368)"
                            fill="#9e9e9e"
                        />
                    </svg>
                    <router-link to="/gallery" style="color: #47B362">
                        Gallery
                    </router-link>
                </p>
            </template>
            <template v-if="this.$i18n.locale == 'ar'">
                <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
                    <router-link to="/" style="color: #9E9E9E">
                        الرئيسية
                    </router-link>

                    <svg
                        class="mx-1"
                        style="transform: rotate(180deg);"
                        xmlns="http://www.w3.org/2000/svg"
                        width="8.947"
                        height="15"
                        viewBox="0 0 8.947 15"
                    >
                        <path
                            id="icons8_forward"
                            d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                            transform="translate(-8.939 -6.368)"
                            fill="#9e9e9e"
                        />
                    </svg>
                    <router-link to="/gallery" style="color: #47B362">
                        معرض الصور
                    </router-link>
                </p>
            </template>
            <div
                class="px-md-0 px-3 mx-auto width-section mt-4"
                style="width:85%"
            >
                <h2 class="heade-content_title" style="color: #636363" data-aos="fade-down"
          data-aos-duration="1000">
                    <template v-if="this.$i18n.locale == 'en'">
                        Gallery
                    </template>
                    <template v-else-if="this.$i18n.locale == 'ar'">
                        معرض الصور
                    </template>
                </h2>
                <LightGallery
                    :images="Files"
                    :index="index"
                    :disable-scroll="true"
                    @close="index = null"
                />
                <div class="row no-gutters my-3" data-aos="fade-up"
          data-aos-duration="1000">
                    <div
                        class="p-2"
                        v-for="(item, thumbIndex) in Files"
                        :key="thumbIndex"
                        @click="index = thumbIndex"
                        :class="(thumbIndex != 0 && thumbIndex != 6 && thumbIndex != 7 && thumbIndex != 13) ? 'col-md-4' : 'col-md-8'"
                    >
                        <img
                            class="w-100 rounded"
                            style="cursor: pointer;height: 300px; object-fit: cover;"
                            :src="item.url"
                        />
                    </div>
                </div>
            </div>
        </div>
          </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            images: {
                donate: "website/imgs/donate.png",
                altadamon: "website/imgs/altadamon.png",
                yemen_bank: "website/imgs/yemen_bank.png",
                dolar: "website/imgs/dolar.svg",
                yr: "website/imgs/yr.svg",
                right: "website/imgs/chevron-right-solid.svg"
            },
            Files: [],
            isLoading: true,
            index: null
        };
    },
    methods: {
        displayFiles() {
            axios.get("api/webSiteGallery").then(response => {
                for (let index = 0; index < response.data.length; index++) {
                    const element = response.data[index];
                    let title = null;
                    if(this.$i18n.locale == 'en'){
                        title = element.title;
                    }else{
                        title = element.title_ar;
                    }
                    this.Files.push({
                        title: title,
                        url: "images/" + element.file
                    });
                }
                this.isLoading = false;
            });
        }
    },
    computed: {

    },
    mounted() {
        this.displayFiles();
    }
};
</script>
