<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="projects"
      v-if="!isLoading"
    >
      <div class="bg-white-2  px-0 mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>

            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              :to="'/sections/' + section.id"
              style="color: #47B362"
            >
              {{section.title}}
            </router-link>
          </p>
          <div
            class="px-md-0 px-3 mx-auto width-section mt-4"
            style="width:70%"
          >
            <div class="row no-gutters">
              <div class="col-12 my-3 px-md-3">
                <img
                  :src="'images/' + section.photo.filename"
                  width="100%"
                  height="500px"
                  style="border-radius: 5px ;object-fit: cover;"
                />
              </div>

              <div class="col-12 my-3 px-md-5">
                <p class="donate-text  mt-3">
                  {{ section.details }}
                </p>
              </div>
            </div>
          </div>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>

            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              :to="'/sections/' + section.id"
              style="color: #47B362"
            >
              {{section.title_ar}}
            </router-link>
          </p>
          <div
            class="px-md-0 px-3 mx-auto width-section mt-4"
            style="width:70%"
          >
            <div class="row no-gutters">
              <div class="col-12 my-3 px-md-3">
                <img
                  :src="'images/' + section.photo.filename"
                  width="100%"
                  height="500px"
                  style="border-radius: 5px ;object-fit: cover;"
                />
              </div>

              <div class="col-12 my-3 px-md-5">
                <p class="donate-text  mt-3 text-right">
                  {{ section.details_ar }}
                </p>
              </div>
            </div>
          </div>
        </template>

        <div
          class="px-md-0 mx-auto width-section mt-4"
          v-if="subsections.length"
        >
          <h2
            class="heade-content_title mb-5"
            style="color: #636363"
          >
            <template v-if="this.$i18n.locale == 'en'">
              Products
            </template>
            <template v-else-if="this.$i18n.locale == 'ar'">
              منتجاتنا
            </template>
          </h2>
          <template v-if="this.$i18n.locale == 'en'">
            <div
              v-for="item in subsections"
              :key="item.id"
              v-if="products.length"
            >
              <div
                class="other_services px-md-5 px-md-4 px-2"
                :style="[( item.id % 2 !== 0) ? {'direction': 'ltr'} : {'direction': 'rtl'}]"
              >
                <div class="other_services_title mx-auto">
                  <h4>{{item.title}}</h4>
                </div>
                <div
                  class="banner__slider h-100 "
                  style=" width: 85% "
                  :style="[( item.id % 2 !== 0) ? {'direction': 'ltr'} : {'direction': 'ltr'}]"
                >
                  <div
                    class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
                    :class="[( item.id % 2 !== 0) ? 'pr-0' : 'pl-0']"
                  >
                    <div
                      class="slide h-100 w-100 p-3"
                      v-for="(i,iex) in item.products"
                      :key="iex"
                      v-if="i.sub_section_id == item.id"
                    >
                      <div class="vueper-slides_content">
                        <img
                          :src="'images/'+ i.photo.filename"
                          alt=""
                          class="w-100 mb-3"
                          style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                        />
                        <router-link :to="'/product/details/'+ i.id">
                          {{i.title}}
                        </router-link>
                      </div>
                    </div>
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    style="display: none;"
                  >
                    <symbol
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 44 44"
                      width="44px"
                      height="44px"
                      id="circle"
                      fill="none"
                      stroke="currentColor"
                    >
                      <circle
                        r="20"
                        cy="22"
                        cx="22"
                        id="test"
                      />
                    </symbol>
                  </svg>
                </div>
              </div>
              <div
                v-if="item.sub_sections.length"
                v-for="(it,ind) in item.sub_sections"
                :key="ind"
                class="other_services px-md-5 px-md-4 px-2"
                :style="[( it.id % 2 !== 0) ? {'direction': 'ltr'} : {'direction': 'rtl'}]"
              >
                <div
                  class="other_services_title mx-auto d-block justify-content-center align-items-center"
                  dir="ltr"
                >
                  <h4>{{it.title}}</h4>
                </div>
                <div
                  class="banner__slider h-100 "
                  style=" width: 85% "
                  :style="[( it.id % 2 !== 0) ? {'direction': 'ltr'} : {'direction': 'ltr'}]"
                >
                  <div
                    class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
                    :class="[( it.id % 2 !== 0) ? 'pr-0' : 'pl-0']"
                  >
                    <div
                      class="slide h-100 w-100 p-3"
                      v-for="(i,inde) in products"
                      :key="inde"
                      v-if="i.sub_section_id == it.id"
                    >
                      <div class="vueper-slides_content">
                        <img
                          :src="'images/'+ i.photo.filename"
                          alt=""
                          class="w-100 mb-3"
                          style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                        />
                        <router-link :to="'/product/details/'+ i.id">
                          {{i.title}}
                        </router-link>
                      </div>
                    </div>
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    style="display: none;"
                  >
                    <symbol
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 44 44"
                      width="44px"
                      height="44px"
                      id="circle"
                      fill="none"
                      stroke="currentColor"
                    >
                      <circle
                        r="20"
                        cy="22"
                        cx="22"
                        id="test"
                      />
                    </symbol>
                  </svg>
                </div>
              </div>
            </div>

          </template>
          <template v-if="this.$i18n.locale == 'ar'">
            <div
              v-for="item in subsections"
              :key="item.id"
              v-if="products.length"
            >
              <div
                class="other_services px-md-5 px-md-4 px-2"
                :style="[( item.id % 2 === 0) ? {'direction': 'ltr'} : {'direction': 'rtl'}]"
              >
                <div class="other_services_title mx-auto">
                  <h4>{{item.title_ar}}</h4>
                </div>
                <div
                  class="banner__slider h-100 "
                  style=" width: 85% "
                  :style="[( item.id % 2 === 0) ? {'direction': 'ltr'} : {'direction': 'ltr'}]"
                >
                  <div
                    class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
                    :class="[( item.id % 2 === 0) ? 'pr-0' : 'pl-0']"
                  >
                    <div
                      class="slide h-100 w-100 p-3"
                      v-for="(i,index) in item.products"
                      :key="index"
                      v-if="i.sub_section_id == item.id"
                    >
                      <div class="vueper-slides_content">
                        <img
                          :src="'images/'+ i.photo.filename"
                          alt=""
                          class="w-100 mb-3"
                          style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                        />
                        <router-link :to="'/product/details/'+ i.id">
                          {{i.title_ar}}
                        </router-link>
                      </div>
                    </div>
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    style="display: none;"
                  >
                    <symbol
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 44 44"
                      width="44px"
                      height="44px"
                      id="circle"
                      fill="none"
                      stroke="currentColor"
                    >
                      <circle
                        r="20"
                        cy="22"
                        cx="22"
                        id="test"
                      />
                    </symbol>
                  </svg>
                </div>
              </div>
              <div
                class="other_services px-md-5 px-md-4 px-2"
                v-if="item.sub_sections.length"
                v-for="(it,indmm) in item.sub_sections"
                :key="indmm"
                :style="[( it.id % 2 === 0) ? {'direction': 'ltr'} : {'direction': 'rtl'}]"
              >
                <div
                  class="other_services_title mx-auto d-block justify-content-center align-items-center"
                  dir="ltr"
                >
                  <h4>{{it.title_ar}}</h4>
                </div>
                <div
                  class="banner__slider h-100 "
                  style=" width: 85% "
                  :style="[( it.id % 2 === 0) ? {'direction': 'ltr'} : {'direction': 'ltr'}]"
                >
                  <div
                    class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
                    :class="[( it.id % 2 === 0) ? 'pr-0' : 'pl-0']"
                  >
                    <div
                      class="slide h-100 w-100 p-3"
                      v-for="(i,mm) in products"
                      :key="mm"
                      v-if="i.sub_section_id == it.id"
                    >
                      <div class="vueper-slides_content">
                        <img
                          :src="'images/'+ i.photo.filename"
                          alt=""
                          class="w-100 mb-3"
                          style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                        />
                        <router-link :to="'/product/details/'+ i.id">
                          {{i.title_ar}}
                        </router-link>
                      </div>
                    </div>
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    style="display: none;"
                  >
                    <symbol
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 44 44"
                      width="44px"
                      height="44px"
                      id="circle"
                      fill="none"
                      stroke="currentColor"
                    >
                      <circle
                        r="20"
                        cy="22"
                        cx="22"
                        id="test"
                      />
                    </symbol>
                  </svg>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        right: "website/imgs/chevron-right-solid.svg",
      },
      isLoading: true,
      visibleSlides: null,
      section: null,
      subsections: [],
      products: [],
    };
  },
  methods: {
    displaySections() {
      let id = this.$route.params.id;
      axios.get("api/sections/" + id).then((response) => {
        this.section = response.data.section;
        this.subsections = response.data.subsections;
        this.products = response.data.products;
        this.isLoading = false;
      });
    },
    winWidth() {
      var w = window.innerWidth;
      if (w < 768) {
        this.visibleSlides = 1;
      } else {
        this.visibleSlides = 4;
      }
    },
  },
  mounted() {
    this.displaySections();
    this.winWidth();
  },
};
</script>
