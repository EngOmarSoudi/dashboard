<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="contact_us"
      v-if="!isLoading"
    >
      <div class="bg-white-2 px-0  mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>

            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/contact-us"
              style="color: #47B362"
            >
              Contact Us
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>

            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/contact-us"
              style="color: #47B362"
            >
              اتصل بنا
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'en'">
          <div class="px-md-5 px-3 mx-auto width-section mt-4">
            <h2
              class="heade-content_title"
              style="color: #636363"
              data-aos="fade-down"
          data-aos-duration="1000"
            >
              Contact Us
            </h2>

            <div class="row no-gutters mt-5" data-aos="fade-up"
          data-aos-duration="1000">
              <div
                class="col-lg-5 my-3 p-4"
                style=" background-color: #034a24; background-image: -webkit-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: -moz-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: -o-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: linear-gradient(62deg, #034a24 0%, #059447 100%); border-radius: 8px"
              >
                <h5
                  class="donate_title"
                  style=" color: white; font-size: 1.1rem; font-weight: bold;"
                >
                  Hello, let's get in touch
                </h5>
                <p
                  class="donate-text"
                  style=" color: white;  font-size: 1.1rem;"
                >
                  We'd love to hear from you, so drop your message and we will contact you.
                </p>

                <div class="d-block mt-5">
                  <div class="d-flex my-3">
                    <img
                      src="website/imgs/logo.svg"
                      style="width: 100%;opacity: .5;"
                    />
                  </div>
                </div>
                <div
                  class="d-flex mt-5"
                  style="border-top: 1.5px solid white;"
                  v-for="item in contact_information"
                  :key="item.id"
                >
                  <a
                    class="my-nav-link  mx-md-0 mx-2"
                    :href="item.facebook_url"
                  >
                    <img :src="images.facebook" />
                  </a>

                  <a
                    class="my-nav-link mx-md-0 mx-2"
                    :href="item.twitter_url"
                  >
                    <img :src="images.twitter" />
                  </a>

                  <a
                    class="my-nav-link mx-md-0 mx-2"
                    :href="item.instagram_url"
                  >
                    <img :src="images.instagram" />
                  </a>
                </div>
              </div>
              <div class="col-lg-7 my-3 px-md-3">
                <form
                  class="row no-gutters"
                  @submit.prevent="creating"
                >

                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.first_name"
                      name="first_name"
                      class="form-control"
                      placeholder="First name"
                    />
                    <span
                      v-if="errors.first_name"
                      class="error"
                    >{{
                                        errors.first_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.last_name"
                      name="last_name"
                      class="form-control"
                      placeholder="Last name"
                    />
                    <span
                      v-if="errors.last_name"
                      class="error"
                    >{{
                                        errors.last_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="email"
                      v-model="form.email"
                      name="email"
                      class="form-control"
                      placeholder="Email"
                    />
                    <span
                      v-if="errors.email"
                      class="error"
                    >{{
                                        errors.email[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.phone_number"
                      name="phone_number"
                      class="form-control"
                      placeholder="Phone number"
                    />
                    <span
                      v-if="errors.phone_number"
                      class="error"
                    >{{
                                        errors.phone_number[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.company_name"
                      name="company_name"
                      class="form-control"
                      placeholder="Company name"
                    />
                    <span
                      v-if="errors.company_name"
                      class="error"
                    >{{
                                        errors.company_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.subject"
                      name="subject"
                      class="form-control"
                      placeholder="Subject"
                    />
                    <span
                      v-if="errors.subject"
                      class="error"
                    >{{
                                        errors.subject[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-12 px-2 text-left">
                    <textarea
                      class="form-control"
                      v-model="form.message"
                      name="message"
                      rows="8"
                      placeholder="Message"
                    ></textarea>
                    <span
                      v-if="errors.message"
                      class="error"
                    >{{
                                        errors.message[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-12 px-2">
                    <button
                      type="submit"
                      :disabled="isDisabled"
                      class="btn float-right"
                      style=" background-color: #059447; color: white; "
                    >
                      Send Message
                    </button>
                  </div>

                </form>
              </div>
            </div>
          </div>
        </template>
        <template v-else-if="this.$i18n.locale == 'ar'">
          <div class="px-md-5 px-3 mx-auto width-section mt-4">
            <h2
              class="heade-content_title"
              style="color: #636363"
              data-aos="fade-down"
          data-aos-duration="1000"
            >
              تواصل بنا
            </h2>

            <div class="row no-gutters mt-5" data-aos="fade-up"
          data-aos-duration="1000">
              <div class="col-lg-7 my-3 px-md-3 order-md-1 order-2">
                <form
                  class="row no-gutters"
                  @submit.prevent="creating"
                  dir="rtl"
                >
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.first_name"
                      name="first_name"
                      class="form-control text-right"
                      placeholder="الاسم الاول "
                    />
                    <span
                      v-if="errors.first_name"
                      class="error"
                    >{{
                                        errors.first_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.last_name"
                      name="last_name"
                      class="form-control text-right"
                      placeholder="اللقب"
                    />
                    <span
                      v-if="errors.last_name"
                      class="error"
                    >{{
                                        errors.last_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="email"
                      v-model="form.email"
                      name="email"
                      class="form-control text-right"
                      placeholder="الايميل"
                    />
                    <span
                      v-if="errors.email"
                      class="error"
                    >{{
                                        errors.email[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.phone_number"
                      name="phone_number"
                      class="form-control text-right"
                      placeholder="رقم الهاتف"
                    />
                    <span
                      v-if="errors.phone_number"
                      class="error"
                    >{{
                                        errors.phone_number[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.company_name"
                      name="company_name"
                      class="form-control text-right"
                      placeholder="اسم الشركة"
                    />
                    <span
                      v-if="errors.company_name"
                      class="error"
                    >{{
                                        errors.company_name[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-md-6 px-2 text-left">
                    <input
                      type="text"
                      v-model="form.subject"
                      name="subject"
                      class="form-control text-right"
                      placeholder="موضوعك"
                    />
                    <span
                      v-if="errors.subject"
                      class="error"
                    >{{
                                        errors.subject[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-12 px-2 text-left">
                    <textarea
                      class="form-control text-right"
                      v-model="form.message"
                      name="message"
                      rows="8"
                      placeholder="رسالتك"
                    ></textarea>
                    <span
                      v-if="errors.message"
                      class="error"
                    >{{
                                        errors.message[0]
                                    }}</span>
                  </div>
                  <div class="form-group col-12 px-2 ">
                    <button
                      type="submit"
                      :disabled="isDisabled"
                      class="btn float-left"
                      style=" background-color: #059447; color: white; "
                    >
                      ارسال رسالة
                    </button>
                  </div>

                </form>
              </div>
              <div
                class="col-lg-5  my-3 p-4"
                style=" background-color: #034a24; background-image: -webkit-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: -moz-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: -o-linear-gradient(62deg, #034a24 0%, #059447 100%); background-image: linear-gradient(62deg, #034a24 0%, #059447 100%); border-radius: 8px"
              >
                <h5
                  class="donate_title text-right"
                  style=" color: white; font-size: 1.1rem; font-weight: bold;"
                >
                  مرحبًا ، دعنا نتواصل
                </h5>
                <p
                  class="donate-text text-right"
                  style=" color: white;  font-size: 1.1rem;"
                >
                  يسعدنا أن نسمع منك ، لذا اترك رسالتك وسنتصل بك.
                </p>
                <div class="d-block mt-5">
                  <div class="d-flex my-3">
                    <img
                      src="website/imgs/logo.svg"
                      style="width: 100%;opacity: .5;"
                    />
                  </div>
                </div>
                <div
                  class="d-flex justify-content-end mt-5"
                  style="border-top: 1.5px solid white;"
                  v-for="item in contact_information"
                  :key="item.id"
                >
                  <a
                    class="my-nav-link  mx-md-0 mx-2"
                    :href="item.facebook_url"
                  >
                    <img :src="images.facebook" />
                  </a>

                  <a
                    class="my-nav-link mx-md-0 mx-2"
                    :href="item.twitter_url"
                  >
                    <img :src="images.twitter" />
                  </a>

                  <a
                    class="my-nav-link mx-md-0 mx-2"
                    :href="item.instagram_url"
                  >
                    <img :src="images.instagram" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        facebook: "website/imgs/facebook_footer.svg",
        twitter: "website/imgs/twitter_footer.svg",
        instagram: "website/imgs/instagram_footer.svg",
        email: "website/imgs/email.svg",
        phone_conract: "website/imgs/phone_conract.svg",
        location: "website/imgs/location.svg",
      },
      isDisabled: false,
      errors: [],
      isLoading: true,
      contact_information: [],
      form: new Form({
        id: "",
        subject: "",
        first_name: "",
        last_name: "",
        email: "",
        phone_number: "",
        message: "",
        company_name: "",
      }),
    };
  },

  methods: {
    displayItems() {
      axios.get("api/contact_information").then((response) => {
        this.contact_information = response.data;
        this.isLoading = false;
      });
    },
    creating() {
      this.isDisabled = true;
      let formData = new FormData();
      formData.append("subject", this.form.subject);
      formData.append("first_name", this.form.first_name);
      formData.append("last_name", this.form.last_name);
      formData.append("phone_number", this.form.phone_number);
      formData.append("company_name", this.form.company_name);
      formData.append("email", this.form.email);
      formData.append("message", this.form.message);

      axios
        .post("api/contect", formData)
        .then((res) => {
          this.errors = [];
          Toast.fire({
            icon: "success",
            title: "Item created in successfully",
          });
          setTimeout(() => (this.isDisabled = false), 2000);
          this.form.reset();
        })
        .catch((err) => {
          this.errors = err.response.data.errors;
          Toast.fire({
            icon: "error",
            title: "Something went wrong creating Item",
          });
          setTimeout(() => (this.isDisabled = false), 2000);
        });
    },
  },
  mounted() {
    this.displayItems();
  },
};
</script>
