<template>
  <div
    class="footer"
    :class="this.$i18n.locale == 'ar' ? 'dir-rtl' : 'dir-ltr'"
  >
    <div class="bg-beneficiaries pt-0 pb-3 mt-5">
      <div class="px-md-0 px-3 mx-auto width-section">
        <div
          class="row no-gutters px-5 py-5 "
          :class="
                        this.$i18n.locale == 'ar' ? 'text-right' : 'text-left'
                    "
        >
          <div class="col-md-5 px-md-2  mx-auto">
            <img
              :src="images.logo_footer"
              width="60%"
            />
            <template v-if="this.$i18n.locale == 'en'">
              <p class="footer_text mt-5">
                Bin Mongy Company for Trading and Importing is a
                well-known company for importing and distributing
                all kinds of agricultural equipment and products
                such as fertilizers, seeds, and pesticides.
              </p>
            </template>
            <template v-else-if="this.$i18n.locale == 'ar'">
              <p class="footer_text mt-5">
                شركة بن منجي للتجارة والاستيراد هي شركة معروفة لاستيراد وتوزيع جميع أنواع المعدات والمنتجات الزراعية مثل الأسمدة والبذور والمبيدات.
              </p>
            </template>

          </div>
          <div class="col-md-4 col-6 px-md-5 pt-5 ">
            <h6 class="footer_title">
              <template v-if="this.$i18n.locale == 'en'">
                Links
              </template>
              <template v-else-if="this.$i18n.locale == 'ar'">
                روابط
              </template>
            </h6>
            <div class="row no-gutters">
              <div class="col-md-6">
                <ul class="navbar-nav p-0 mt-md-4 mt-0">
                  <li class="nav-item">
                    <router-link
                      to="/"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("home") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/about-us"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("AboutUs") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/news"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("News") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/food-staff"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("FoodStaff") }}
                    </router-link>
                  </li>
                </ul>
              </div>
              <div class="col-md-6">
                <ul class="navbar-nav  p-0 mt-md-4 mt-0">
                  <li class="nav-item">
                    <router-link
                      to="/gallery"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("Gallery") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/partnership"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("Partnership") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/branches"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("Branches") }}
                    </router-link>
                  </li>
                  <li class="nav-item">
                    <router-link
                      to="/contact-us"
                      tag="li"
                      class="nav-link font-weight-bold"
                      exact
                    >
                      {{ $t("ContactUs") }}
                    </router-link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-3 px-md-5  mx-auto text-center">
            <p class="footer_text mt-4">
              <template v-if="this.$i18n.locale == 'en'">
                Don't be shy to say "Hi"
              </template>
              <template v-else-if="this.$i18n.locale == 'ar'">
                لا تخجل من قول "مرحبًا"
              </template>
            </p>
            <div
              class="d-flex justify-content-center"
              v-for="item in contact_information"
              :key="item.id"
            >
              <a
                :href="item.facebook_url"
                class="mx-3"
              >
                <img
                  :src="images.facebook_footer"
                  width="30px"
                />
              </a>

              <a
                :href="item.twitter_url"
                class="mx-3"
              >
                <img
                  :src="images.twitter_footer"
                  width="30px"
                />
              </a>

              <a
                :href="item.instagram_url"
                class="mx-3"
              >
                <img
                  :src="images.instagram_footer"
                  width="30px"
                />
              </a>
            </div>
          </div>
        </div>
        <div class="row no-gutters mt-0 ">
          <span class="lebal_footer my-3"></span>
        </div>

        <p class="footer_text mb-0 text-center">
          <template v-if="this.$i18n.locale == 'en'">
            All rights are reserved to Temmam Light Co.
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
            جميع الحقوق محفوظة لشركة تمام لايت.
          </template>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        logo_footer: "website/imgs/logo_footer.svg",
        right_footer: "website/imgs/right_footer.svg",
        phone: "website/imgs/phone.svg",
        facebook_footer: "website/imgs/facebook_footer.svg",
        twitter_footer: "website/imgs/twitter_footer.svg",
        instagram_footer: "website/imgs/instagram_footer.svg",
      },
      contact_information: [],
    };
  },
  methods: {
    displayItems() {
      axios.get("api/contact_information").then((response) => {
        this.contact_information = response.data;
      });
    },
  },
  mounted() {
    this.displayItems();
  },
};
</script>
