<template>
  <div
    class="mynavbar"
    :class="this.$i18n.locale == 'ar' ? 'dir-rtl' : 'dir-ltr'"
  >
    <nav
      class="navbar  navbar-expand-lg navbar-dark fixed-top  px-md-4 px-2 "
      v-show="this.$route.name == 'home'"
      id="navbar-index"
    >
      <router-link to="/">
        <a class="navbar-brand d-flex  align-items-center">
          <img
            :src="images.logo"
            class="logo"
          />
        </a>
      </router-link>
      <button
        class="navbar-toggler border-0"
        type="button"
        data-toggle="collapse"
        data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div
        class="collapse navbar-collapse "
        id="navbarNavDropdown"
      >
        <ul
          class="navbar-nav  align-items-center"
          :class="this.$i18n.locale == 'ar' ? 'mr-auto' : 'ml-auto'"
        >
          <li class="nav-item ">
            <router-link
              to="/"
              tag="li"
              class="mynavlink"
              exact
            >
              <a class="my-nav-link">{{ $t("home") }}</a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/about-us"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("AboutUs") }} </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/news"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("News") }} </a>
            </router-link>
          </li>
          <template v-if="this.$i18n.locale == 'en'">
            <li
              class="nav-item section-item"
              v-for="(section, index) in sections"
              :key="index"
            >
              <a class="my-nav-link">{{ section.title }}</a>
              <ul
                class="section-subitem"
                v-if="section.subsections.length"
              >

                <li
                  v-for="(item, index) in section.subsections"
                  :key="index"
                >
                  <a
                    :href="'/sections/'+section.id"
                    tag="li"
                    target="_self"
                  >
                    {{ item.title }}
                  </a>
                  <ul class="section-subitem-sub" v-if="item.subsections.length">
                    <li
                      v-for="(item, index) in item.subsections"
                      :key="index"
                    >
                      <a
                        :href="'/sections/'+section.id"
                        tag="li"
                        target="_self"
                      >
                        {{ item.title }}
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
             <li
              class="nav-item section-item"
              v-for="(section, index) in sections"
              :key="index"
            >
              <a class="my-nav-link">{{ section.title_ar }}</a>
              <ul
                class="section-subitem"
                v-if="section.subsections.length"
              >

                <li
                  v-for="(item, index) in section.subsections"
                  :key="index"
                >
                  <a
                    :href="'/sections/'+section.id"
                    tag="li"
                    target="_self"
                  >
                    {{ item.title_ar }}
                  </a>
                  <ul class="section-subitem-sub-ar" v-if="item.subsections.length">
                    <li
                      v-for="(item, index) in item.subsections"
                      :key="index"
                    >
                      <a
                        :href="'/sections/'+section.id"
                        tag="li"
                        target="_self"
                      >
                        {{ item.title_ar }}
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </template>
          <li class="nav-item">
            <router-link
              to="/agencies"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("Agencies") }}</a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/partnership"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("Partnership") }} </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/gallery"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("Gallery") }} </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/branches"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("Branches") }} </a>
            </router-link>
          </li>

          <li class="nav-item">
            <router-link
              to="/contact-us"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link">{{ $t("ContactUs") }} </a>
            </router-link>
          </li>

          <li
            class="nav-item "
            v-if="this.$i18n.locale == 'ar'"
            style=" cursor: pointer; "
          >
            <a
              @click="setLocale('en')"
              target="_self"
              class="my-nav-link d-flex align-items-center justify-content-center"
            >
              <svg
                class="mx-1"
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="23.746"
                viewBox="0 0 25 23.746"
              >
                <path
                  id="icons8_language"
                  d="M4.5,3A2.5,2.5,0,0,0,2,5.5v15A2.5,2.5,0,0,0,4.5,23H22l3.485,3.485A.888.888,0,0,0,27,25.857V5.5A2.5,2.5,0,0,0,24.5,3Zm5,5h0a1.5,1.5,0,0,1,1.391.944l3.021,7.583a1.076,1.076,0,0,1-1,1.474h0a1.075,1.075,0,0,1-1.013-.712l-.486-1.358H7.586L7.1,17.288A1.074,1.074,0,0,1,6.086,18h0a1.075,1.075,0,0,1-1-1.474L8.109,8.944A1.5,1.5,0,0,1,9.5,8ZM20.125,8h0a.86.86,0,0,1,.86.859v.82h2.682a.834.834,0,0,1,.833.834v.807A6.575,6.575,0,0,1,21.688,16.2c.2.033.406.06.618.08a.836.836,0,0,1,.75.836h0a.838.838,0,0,1-.9.84,9.5,9.5,0,0,1-2.653-.624,11.432,11.432,0,0,1-2.854.615.83.83,0,0,1-.9-.835h0a.834.834,0,0,1,.781-.825,8.681,8.681,0,0,0,1.06-.128,6.522,6.522,0,0,1-1.659-2.785.851.851,0,0,1,.825-1.081h.021a.862.862,0,0,1,.835.6,4.883,4.883,0,0,0,1.97,2.6,5.338,5.338,0,0,0,3.047-4.18H16.571a.819.819,0,0,1-.821-.819h0a.82.82,0,0,1,.82-.82h2.695V8.859A.86.86,0,0,1,20.125,8ZM9.5,10.539l-1.329,3.75h2.656Z"
                  transform="translate(-2 -3)"
                  fill="#b1b1b1"
                />
              </svg>
              <span>English</span>
            </a>
          </li>
          <li
            class="nav-item "
            v-if="this.$i18n.locale == 'en'"
            style=" cursor: pointer; "
          >
            <a
              @click="setLocale('ar')"
              target="_self"
              class="my-nav-link d-flex align-items-center justify-content-center"
            >
              <span>العربية</span>
              <svg
                class="mx-1"
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="23.746"
                viewBox="0 0 25 23.746"
              >
                <path
                  id="icons8_language"
                  d="M4.5,3A2.5,2.5,0,0,0,2,5.5v15A2.5,2.5,0,0,0,4.5,23H22l3.485,3.485A.888.888,0,0,0,27,25.857V5.5A2.5,2.5,0,0,0,24.5,3Zm5,5h0a1.5,1.5,0,0,1,1.391.944l3.021,7.583a1.076,1.076,0,0,1-1,1.474h0a1.075,1.075,0,0,1-1.013-.712l-.486-1.358H7.586L7.1,17.288A1.074,1.074,0,0,1,6.086,18h0a1.075,1.075,0,0,1-1-1.474L8.109,8.944A1.5,1.5,0,0,1,9.5,8ZM20.125,8h0a.86.86,0,0,1,.86.859v.82h2.682a.834.834,0,0,1,.833.834v.807A6.575,6.575,0,0,1,21.688,16.2c.2.033.406.06.618.08a.836.836,0,0,1,.75.836h0a.838.838,0,0,1-.9.84,9.5,9.5,0,0,1-2.653-.624,11.432,11.432,0,0,1-2.854.615.83.83,0,0,1-.9-.835h0a.834.834,0,0,1,.781-.825,8.681,8.681,0,0,0,1.06-.128,6.522,6.522,0,0,1-1.659-2.785.851.851,0,0,1,.825-1.081h.021a.862.862,0,0,1,.835.6,4.883,4.883,0,0,0,1.97,2.6,5.338,5.338,0,0,0,3.047-4.18H16.571a.819.819,0,0,1-.821-.819h0a.82.82,0,0,1,.82-.82h2.695V8.859A.86.86,0,0,1,20.125,8ZM9.5,10.539l-1.329,3.75h2.656Z"
                  transform="translate(-2 -3)"
                  fill="#b1b1b1"
                />
              </svg>
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <nav
      class="navbar navbar-expand-lg navbar-dark fixed-top  px-md-4 px-2 "
      v-show="this.$route.name !== 'home'"
      style="background-color:#066632; box-shadow: 0px 1px 10px #999 "
    >
      <router-link to="/">
        <a class="navbar-brand d-flex  align-items-center">
          <img
            :src="images.logo"
            class="logo"
          />
        </a>
      </router-link>
      <button
        class="navbar-toggler border-0"
        type="button"
        data-toggle="collapse"
        data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div
        class="collapse navbar-collapse "
        id="navbarNavDropdown"
      >
        <ul
          class="navbar-nav  align-items-center"
          :class="this.$i18n.locale == 'ar' ? 'mr-auto' : 'ml-auto'"
        >
          <li class="nav-item ">
            <router-link
              to="/"
              tag="li"
              class="mynavlink"
              exact
            >
              <a class="my-nav-link-2">{{ $t("home") }}
              </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/about-us"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{ $t("AboutUs") }}
              </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/news"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{
                                $t("News")
                            }}</a>
            </router-link>
          </li>
          <template v-if="this.$i18n.locale == 'en'">
            <li
              class="nav-item section-item"
              v-for="(section, index) in sections"
              :key="index"
            >
              <a class="my-nav-link">{{ section.title }}</a>
              <ul
                class="section-subitem"
                v-if="section.subsections.length"
              >

                <li
                  v-for="(item, index) in section.subsections"
                  :key="index"
                >
                  <a
                    :href="'/sections/'+section.id"
                    tag="li"
                    target="_self"
                  >
                    {{ item.title }}
                  </a>
                  <ul class="section-subitem-sub" v-if="item.subsections.length">
                    <li
                      v-for="(item, index) in item.subsections"
                      :key="index"
                    >
                      <a
                        :href="'/sections/'+section.id"
                        tag="li"
                        target="_self"
                      >
                        {{ item.title }}
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
             <li
              class="nav-item section-item"
              v-for="(section, index) in sections"
              :key="index"
            >
              <a class="my-nav-link">{{ section.title_ar }}</a>
              <ul
                class="section-subitem"
                v-if="section.subsections.length"
              >

                <li
                  v-for="(item, index) in section.subsections"
                  :key="index"
                >
                  <a
                    :href="'/sections/'+section.id"
                    tag="li"
                    target="_self"
                  >
                    {{ item.title_ar }}
                  </a>
                  <ul class="section-subitem-sub-ar" v-if="item.subsections.length">
                    <li
                      v-for="(item, index) in item.subsections"
                      :key="index"
                    >
                      <a
                        :href="'/sections/'+section.id"
                        tag="li"
                        target="_self"
                      >
                        {{ item.title_ar }}
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
          </template>
          <li class="nav-item">
            <router-link
              to="/agencies"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{
                                $t("Agencies")
                            }}</a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/partnership"
              tag="li"
              class="mynavlink "
            >
              <a class="my-nav-link-2">{{
                                $t("Partnership")
                            }}</a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/gallery"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{ $t("Gallery") }}
              </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/branches"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{ $t("Branches") }}
              </a>
            </router-link>
          </li>
          <li class="nav-item">
            <router-link
              to="/contact-us"
              tag="li"
              class="mynavlink"
            >
              <a class="my-nav-link-2">{{ $t("ContactUs") }}
              </a>
            </router-link>
          </li>
          <li
            class="nav-item "
            v-if="this.$i18n.locale == 'ar'"
            style=" cursor: pointer; "
          >
            <a
              @click="setLocale('en')"
              target="_self"
              class="my-nav-link d-flex align-items-center justify-content-center"
            >
              <svg
                class="mx-1"
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="23.746"
                viewBox="0 0 25 23.746"
              >
                <path
                  id="icons8_language"
                  d="M4.5,3A2.5,2.5,0,0,0,2,5.5v15A2.5,2.5,0,0,0,4.5,23H22l3.485,3.485A.888.888,0,0,0,27,25.857V5.5A2.5,2.5,0,0,0,24.5,3Zm5,5h0a1.5,1.5,0,0,1,1.391.944l3.021,7.583a1.076,1.076,0,0,1-1,1.474h0a1.075,1.075,0,0,1-1.013-.712l-.486-1.358H7.586L7.1,17.288A1.074,1.074,0,0,1,6.086,18h0a1.075,1.075,0,0,1-1-1.474L8.109,8.944A1.5,1.5,0,0,1,9.5,8ZM20.125,8h0a.86.86,0,0,1,.86.859v.82h2.682a.834.834,0,0,1,.833.834v.807A6.575,6.575,0,0,1,21.688,16.2c.2.033.406.06.618.08a.836.836,0,0,1,.75.836h0a.838.838,0,0,1-.9.84,9.5,9.5,0,0,1-2.653-.624,11.432,11.432,0,0,1-2.854.615.83.83,0,0,1-.9-.835h0a.834.834,0,0,1,.781-.825,8.681,8.681,0,0,0,1.06-.128,6.522,6.522,0,0,1-1.659-2.785.851.851,0,0,1,.825-1.081h.021a.862.862,0,0,1,.835.6,4.883,4.883,0,0,0,1.97,2.6,5.338,5.338,0,0,0,3.047-4.18H16.571a.819.819,0,0,1-.821-.819h0a.82.82,0,0,1,.82-.82h2.695V8.859A.86.86,0,0,1,20.125,8ZM9.5,10.539l-1.329,3.75h2.656Z"
                  transform="translate(-2 -3)"
                  fill="#b1b1b1"
                />
              </svg>
              <span>English</span>
            </a>
          </li>
          <li
            class="nav-item "
            v-if="this.$i18n.locale == 'en'"
            style=" cursor: pointer; "
          >
            <a
              @click="setLocale('ar')"
              target="_self"
              class="my-nav-link d-flex align-items-center justify-content-center"
            >
              <span>العربية</span>
              <svg
                class="mx-1"
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="23.746"
                viewBox="0 0 25 23.746"
              >
                <path
                  id="icons8_language"
                  d="M4.5,3A2.5,2.5,0,0,0,2,5.5v15A2.5,2.5,0,0,0,4.5,23H22l3.485,3.485A.888.888,0,0,0,27,25.857V5.5A2.5,2.5,0,0,0,24.5,3Zm5,5h0a1.5,1.5,0,0,1,1.391.944l3.021,7.583a1.076,1.076,0,0,1-1,1.474h0a1.075,1.075,0,0,1-1.013-.712l-.486-1.358H7.586L7.1,17.288A1.074,1.074,0,0,1,6.086,18h0a1.075,1.075,0,0,1-1-1.474L8.109,8.944A1.5,1.5,0,0,1,9.5,8ZM20.125,8h0a.86.86,0,0,1,.86.859v.82h2.682a.834.834,0,0,1,.833.834v.807A6.575,6.575,0,0,1,21.688,16.2c.2.033.406.06.618.08a.836.836,0,0,1,.75.836h0a.838.838,0,0,1-.9.84,9.5,9.5,0,0,1-2.653-.624,11.432,11.432,0,0,1-2.854.615.83.83,0,0,1-.9-.835h0a.834.834,0,0,1,.781-.825,8.681,8.681,0,0,0,1.06-.128,6.522,6.522,0,0,1-1.659-2.785.851.851,0,0,1,.825-1.081h.021a.862.862,0,0,1,.835.6,4.883,4.883,0,0,0,1.97,2.6,5.338,5.338,0,0,0,3.047-4.18H16.571a.819.819,0,0,1-.821-.819h0a.82.82,0,0,1,.82-.82h2.695V8.859A.86.86,0,0,1,20.125,8ZM9.5,10.539l-1.329,3.75h2.656Z"
                  transform="translate(-2 -3)"
                  fill="#b1b1b1"
                />
              </svg>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        logo: "website/imgs/logo_footer.svg",
        facebook: "website/imgs/facebook.svg",
        twitter: "website/imgs/twitter.svg",
        instagram: "website/imgs/instagram.svg",
      },
      Agriculture: [],
      Food: [],
      Renewable: [],
      Others: [],
      sections: [],
    };
  },
  mounted() {
    if (localStorage.locale != null) this.$i18n.locale = localStorage.locale;
  },
  methods: {
    displaySections() {
      axios.get("api/webSiteSections").then((response) => {
        this.sections = response.data;
      });
    },
    setLocale(locale) {
      localStorage.locale = locale;
      location.reload();
    },
    scrollFunction() {
      window.onscroll = function () {
        if (
          document.body.scrollTop > 20 ||
          document.documentElement.scrollTop > 20
        ) {
          document.getElementById("navbar-index").style["background-color"] =
            "#066632";
          document.getElementById("navbar-index").style["box-shadow"] =
            "0px 1px 10px #999";
        } else {
          document.getElementById("navbar-index").style["background-color"] =
            "inherit";
          document.getElementById("navbar-index").style["box-shadow"] =
            "0px 0px 0px #eee";
        }
      };
    },
    displayAgriculture() {
      axios.get("api/webSiteAgriculture").then((response) => {
        this.Agriculture = response.data;
      });
    },
    displayFood() {
      axios.get("api/webSiteFood").then((response) => {
        this.Food = response.data;
      });
    },
    displayRenewable() {
      axios.get("api/webSiteRenewable").then((response) => {
        this.Renewable = response.data;
      });
    },
    displayOthers() {
      axios.get("api/webSiteOthers").then((response) => {
        this.Others = response.data;
      });
    },
  },
  created() {
    this.displaySections();
    // this.displayAgriculture();
    // this.displayFood();
    // this.displayRenewable();
    // this.displayOthers();
    this.scrollFunction();
  },
};
</script>
