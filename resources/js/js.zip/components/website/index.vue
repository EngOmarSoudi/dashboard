<template>
  <div>
    <navbarindex></navbarindex>
    <router-view></router-view>
    <footerwebsite></footerwebsite>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
};
</script>
