<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="contact_us"
      v-if="!isLoading"
    >
      <div class="bg-white-2 px-0  mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>

            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/branches"
              style="color: #47B362"
            >
              Branches
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>

            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/branches"
              style="color: #47B362"
            >
              الفروع
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'en'">
          <div
            class="px-md-5 px-3 mx-auto width-section mt-4"
            v-if="branche_item"
          >
            <h2
              class="heade-content_title"
              style="color: #636363"
              data-aos="fade-down"
          data-aos-duration="1000"
            >
              Branches
            </h2>

            <div class="row no-gutters mt-5" data-aos="fade-up"
          data-aos-duration="1000"> 
              <div
                class="col-lg-3 my-3 p-4"
                style=" background-color: #EDFAF1; border-radius: 8px 0 0 8px"
              >
                <h5
                  class="donate_title text-center mb-3"
                  style=" color: #3B3B3B; font-size: 1.1rem; font-weight: bold;"
                >
                  {{branche_item.name}}
                </h5>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 25"
                    >
                      <path
                        id="icons8_businessman"
                        d="M15.5,3a5.556,5.556,0,1,0,5.556,5.556A5.556,5.556,0,0,0,15.5,3Zm0,15.278c-4.172,0-12.5,2.094-12.5,6.25v2.083A1.389,1.389,0,0,0,4.389,28h8.968l.928-5.556-.233-.925a1.493,1.493,0,1,1,2.9,0l-.233.925L17.643,28h8.968A1.389,1.389,0,0,0,28,26.611V24.528C28,20.372,19.672,18.278,15.5,18.278Z"
                        transform="translate(-3 -3)"
                        fill="#62c47b"
                      />
                    </svg>

                    The Branch Manager
                  </span>
                  {{branche_item.branch_manager}}
                </p>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 20"
                    >
                      <path
                        id="icons8_new_post"
                        d="M4.5,4A2.492,2.492,0,0,0,2.029,6.207L14.5,14,26.971,6.207A2.492,2.492,0,0,0,24.5,4ZM2,8.69V21.5A2.5,2.5,0,0,0,4.5,24h20A2.5,2.5,0,0,0,27,21.5V8.69l-11.838,7.4a1.25,1.25,0,0,1-1.323,0Z"
                        transform="translate(-2 -4)"
                        fill="#62c47b"
                      />
                    </svg>
                    Email
                  </span>
                  {{branche_item.email}}
                </p>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 39.286"
                    >
                      <path
                        id="icons8_iphone"
                        d="M25.536,1H9.464A4.466,4.466,0,0,0,5,5.464V35.821a4.466,4.466,0,0,0,4.464,4.464H25.536A4.466,4.466,0,0,0,30,35.821V5.464A4.466,4.466,0,0,0,25.536,1ZM17.5,36.937a2.009,2.009,0,1,1,2.009-2.009A2.007,2.007,0,0,1,17.5,36.937Zm7.143-5.58H10.357a1.786,1.786,0,0,1-1.786-1.786V8.143a1.786,1.786,0,0,1,1.786-1.786H24.643a1.786,1.786,0,0,1,1.786,1.786V29.571A1.786,1.786,0,0,1,24.643,31.357Z"
                        transform="translate(-5 -1)"
                        fill="#62c47b"
                      />
                    </svg>
                    Mobile
                  </span>
                  {{branche_item.phone}}
                </p>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 25"
                    >
                      <path
                        id="icons8_phone"
                        d="M25.563,20.044l-3.507-.4a2.77,2.77,0,0,0-2.282.793L17.2,23.009a20.943,20.943,0,0,1-9.171-9.171L10.6,11.263A2.77,2.77,0,0,0,11.4,8.98l-.4-3.507A2.785,2.785,0,0,0,8.222,3.01H5.815A2.762,2.762,0,0,0,3.031,5.891,23.646,23.646,0,0,0,25.146,28a2.762,2.762,0,0,0,2.881-2.783V22.814A2.785,2.785,0,0,0,25.563,20.044Z"
                        transform="translate(-3.026 -3.01)"
                        fill="#62c47b"
                      />
                    </svg>
                    Phone
                  </span>
                  {{branche_item.telephone}}
                </p>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 23.75"
                    >
                      <path
                        id="icons8_fax"
                        d="M14.5,3a1.25,1.25,0,0,0-1.25,1.25V8H12a2.5,2.5,0,0,0-2.5,2.5v8.75a2.5,2.5,0,0,0,2.5,2.5h1.25V23A1.23,1.23,0,0,1,12,24.25H7A1.23,1.23,0,0,1,5.75,23V21.635A1.87,1.87,0,0,0,7,19.875V7.375A1.876,1.876,0,0,0,5.125,5.5H3.875A1.876,1.876,0,0,0,2,7.375v12.5a1.87,1.87,0,0,0,1.25,1.76V23A3.769,3.769,0,0,0,7,26.75h5A3.769,3.769,0,0,0,15.75,23V21.75H24.5a2.5,2.5,0,0,0,2.5-2.5V10.5A2.5,2.5,0,0,0,24.5,8H23.25V4.25A1.25,1.25,0,0,0,22,3Zm1.25,2.5h5V9.25h-5Zm-.625,6.25h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,15.125,11.75Zm5,0h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,20.125,11.75Zm-5,5h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,15.125,16.75Zm5,0h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,20.125,16.75Z"
                        transform="translate(-2 -3)"
                        fill="#62c47b"
                      />
                    </svg>
                    Fax
                  </span>
                  {{branche_item.fax}}
                </p>
                <p
                  class="donate-text"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="mr-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 34.717"
                    >
                      <path
                        id="icons8_marker"
                        d="M17.5,2A12.5,12.5,0,0,0,5,14.5c0,7.082,7.864,17.536,11.118,21.555a1.774,1.774,0,0,0,2.764,0C22.136,32.036,30,21.582,30,14.5A12.5,12.5,0,0,0,17.5,2Zm0,16.964A4.464,4.464,0,1,1,21.964,14.5,4.464,4.464,0,0,1,17.5,18.964Z"
                        transform="translate(-5 -2)"
                        fill="#62c47b"
                      />
                    </svg>
                    The Branch Address
                  </span>
                  {{branche_item.main_address}}
                </p>

              </div>
              <div class="col-lg-9 my-3">
                <GmapMap
                  class="branches_map"
                  v-if="branches[0].markers"
                  :center="{
                                                            lat: branches[0].markers.position.lat,
                                                            lng: branches[0].markers.position.lng
                                                        }"
                  :zoom="7"
                  map-type-id="terrain"
                >
                  <GmapMarker
                    v-for="(item, index) in branches"
                    :key="index"
                    :position="item.markers.position"
                    :clickable="true"
                    @click="loadData(item.id)"
                    :draggable="false"
                    :icon="item.markers.icon"
                  />
                </GmapMap>
              </div>
            </div>
          </div>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <div
            class="px-md-5 px-3 mx-auto width-section mt-4"
            dir="rtl"
            v-if="branche_item"
          >
            <h2
              class="heade-content_title"
              style="color: #636363"
              data-aos="fade-down"
          data-aos-duration="1000"
            >
              الفروع
            </h2>

            <div class="row no-gutters mt-5" data-aos="fade-up"
          data-aos-duration="1000">
              <div
                class="col-lg-3 my-3 p-4"
                style=" background-color: #EDFAF1; border-radius:  0 8px 8px 0"
              >
                <h5
                  class="donate_title text-center mb-3"
                  style=" color: #3B3B3B; font-size: 1.1rem; font-weight: bold;"
                >
                  {{branche_item.name_ar}}
                </h5>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 25"
                    >
                      <path
                        id="icons8_businessman"
                        d="M15.5,3a5.556,5.556,0,1,0,5.556,5.556A5.556,5.556,0,0,0,15.5,3Zm0,15.278c-4.172,0-12.5,2.094-12.5,6.25v2.083A1.389,1.389,0,0,0,4.389,28h8.968l.928-5.556-.233-.925a1.493,1.493,0,1,1,2.9,0l-.233.925L17.643,28h8.968A1.389,1.389,0,0,0,28,26.611V24.528C28,20.372,19.672,18.278,15.5,18.278Z"
                        transform="translate(-3 -3)"
                        fill="#62c47b"
                      />
                    </svg>

                    مدير الفرع
                  </span>
                  {{branche_item.branch_manager}}
                </p>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 20"
                    >
                      <path
                        id="icons8_new_post"
                        d="M4.5,4A2.492,2.492,0,0,0,2.029,6.207L14.5,14,26.971,6.207A2.492,2.492,0,0,0,24.5,4ZM2,8.69V21.5A2.5,2.5,0,0,0,4.5,24h20A2.5,2.5,0,0,0,27,21.5V8.69l-11.838,7.4a1.25,1.25,0,0,1-1.323,0Z"
                        transform="translate(-2 -4)"
                        fill="#62c47b"
                      />
                    </svg>
                    الايميل
                  </span>
                  {{branche_item.email}}
                </p>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                  dir="ltr"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                    dir="rtl"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 39.286"
                    >
                      <path
                        id="icons8_iphone"
                        d="M25.536,1H9.464A4.466,4.466,0,0,0,5,5.464V35.821a4.466,4.466,0,0,0,4.464,4.464H25.536A4.466,4.466,0,0,0,30,35.821V5.464A4.466,4.466,0,0,0,25.536,1ZM17.5,36.937a2.009,2.009,0,1,1,2.009-2.009A2.007,2.007,0,0,1,17.5,36.937Zm7.143-5.58H10.357a1.786,1.786,0,0,1-1.786-1.786V8.143a1.786,1.786,0,0,1,1.786-1.786H24.643a1.786,1.786,0,0,1,1.786,1.786V29.571A1.786,1.786,0,0,1,24.643,31.357Z"
                        transform="translate(-5 -1)"
                        fill="#62c47b"
                      />
                    </svg>
                    رقم الموبايل
                  </span>
                  {{branche_item.phone}}
                </p>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                  dir="ltr"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                    dir="rtl"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 25"
                    >
                      <path
                        id="icons8_phone"
                        d="M25.563,20.044l-3.507-.4a2.77,2.77,0,0,0-2.282.793L17.2,23.009a20.943,20.943,0,0,1-9.171-9.171L10.6,11.263A2.77,2.77,0,0,0,11.4,8.98l-.4-3.507A2.785,2.785,0,0,0,8.222,3.01H5.815A2.762,2.762,0,0,0,3.031,5.891,23.646,23.646,0,0,0,25.146,28a2.762,2.762,0,0,0,2.881-2.783V22.814A2.785,2.785,0,0,0,25.563,20.044Z"
                        transform="translate(-3.026 -3.01)"
                        fill="#62c47b"
                      />
                    </svg>
                    رقم الهاتف الثابت
                  </span>
                  {{branche_item.telephone}}
                </p>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                  dir="ltr"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                    dir="rtl"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 23.75"
                    >
                      <path
                        id="icons8_fax"
                        d="M14.5,3a1.25,1.25,0,0,0-1.25,1.25V8H12a2.5,2.5,0,0,0-2.5,2.5v8.75a2.5,2.5,0,0,0,2.5,2.5h1.25V23A1.23,1.23,0,0,1,12,24.25H7A1.23,1.23,0,0,1,5.75,23V21.635A1.87,1.87,0,0,0,7,19.875V7.375A1.876,1.876,0,0,0,5.125,5.5H3.875A1.876,1.876,0,0,0,2,7.375v12.5a1.87,1.87,0,0,0,1.25,1.76V23A3.769,3.769,0,0,0,7,26.75h5A3.769,3.769,0,0,0,15.75,23V21.75H24.5a2.5,2.5,0,0,0,2.5-2.5V10.5A2.5,2.5,0,0,0,24.5,8H23.25V4.25A1.25,1.25,0,0,0,22,3Zm1.25,2.5h5V9.25h-5Zm-.625,6.25h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,15.125,11.75Zm5,0h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,20.125,11.75Zm-5,5h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,15.125,16.75Zm5,0h1.25a.625.625,0,0,1,.625.625v1.25a.625.625,0,0,1-.625.625h-1.25a.625.625,0,0,1-.625-.625v-1.25A.625.625,0,0,1,20.125,16.75Z"
                        transform="translate(-2 -3)"
                        fill="#62c47b"
                      />
                    </svg>
                    فاكس
                  </span>
                  {{branche_item.fax}}
                </p>
                <p
                  class="donate-text text-right"
                  style="color: #3B3B3B; font-size: 1rem; font-weight: bold;"
                >
                  <span
                    class="d-flex align-items-center mb-1"
                    style="color:#62C47B; font-size: 0.9rem; font-weight: normal;"
                  >
                    <svg
                      class="ml-2"
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 25 34.717"
                    >
                      <path
                        id="icons8_marker"
                        d="M17.5,2A12.5,12.5,0,0,0,5,14.5c0,7.082,7.864,17.536,11.118,21.555a1.774,1.774,0,0,0,2.764,0C22.136,32.036,30,21.582,30,14.5A12.5,12.5,0,0,0,17.5,2Zm0,16.964A4.464,4.464,0,1,1,21.964,14.5,4.464,4.464,0,0,1,17.5,18.964Z"
                        transform="translate(-5 -2)"
                        fill="#62c47b"
                      />
                    </svg>
                    عنوان الفرع
                  </span>
                  {{branche_item.main_address_ar}}
                </p>

              </div>
              <div class="col-lg-9 my-3">
                <GmapMap
                  class="branches_map"
                  v-if="branches[0].markers"
                  :center="{
                                                            lat: branches[0].markers.position.lat,
                                                            lng: branches[0].markers.position.lng
                                                        }"
                  :zoom="7"
                  map-type-id="terrain"
                >
                  <GmapMarker
                    v-for="(item, index) in branches"
                    :key="index"
                    :position="item.markers.position"
                    :clickable="true"
                    @click="loadData(item.id)"
                    :draggable="false"
                    :icon="item.markers.icon"
                  />
                </GmapMap>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: true,
      branches: [],
      branche_item: null,
    };
  },

  methods: {
    displayItems() {
      axios.get("api/branches").then((response) => {
        for (var i = 0; i < response.data.length; i++) {
          this.branches.push({
            id: response.data[i].id,
            name: response.data[i].name,
            name_ar: response.data[i].name_ar,
            branch_manager: response.data[i].branch_manager,
            email: response.data[i].email,
            fax: response.data[i].fax,
            main_address: response.data[i].main_address,
            main_address_ar: response.data[i].main_address_ar,
            phone: response.data[i].phone,
            telephone: response.data[i].telephone,
            markers: {
              position: {
                lat: parseFloat(response.data[i].lat),
                lng: parseFloat(response.data[i].lng),
              },
              icon: {
                url: "website/imgs/map.svg",
                scaledSize: this.google && new google.maps.Size(28, 28),
                labelOrigin: this.google && new google.maps.Point(16, -10),
              },
              title: "title",
            },
          });
        }
        this.branche_item = this.branches[0];
        this.isLoading = false;
      });
    },
    loadData(id) {
      for (let index = 0; index < this.branches.length; index++) {
        const element = this.branches[index];
        if (element.id == id) {
          this.branche_item = element;
        }
      }
    },
  },
  mounted() {
    this.displayItems();
  },
};
</script>
