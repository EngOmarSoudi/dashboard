<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="about-us"
      v-if="!isLoading"
    >
      <div class="bg-white-2 px-0  mt-5">
        <template v-if="this.$i18n.locale == 'en'">
          <p class="heade-content_title text-left px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              Home
            </router-link>

            <svg
              class="mx-1"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/agencies"
              style="color: #47B362"
            >
              Agencies
            </router-link>
          </p>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <p class="heade-content_title text-right px-md-5 px-md-4 px-2 mt-0">
            <router-link
              to="/"
              style="color: #9E9E9E"
            >
              الرئيسية
            </router-link>

            <svg
              class="mx-1"
              style="transform: rotate(180deg);"
              xmlns="http://www.w3.org/2000/svg"
              width="8.947"
              height="15"
              viewBox="0 0 8.947 15"
            >
              <path
                id="icons8_forward"
                d="M14.442,13.869,9.353,8.78a1.413,1.413,0,0,1,0-2h0a1.413,1.413,0,0,1,2,0L17.5,12.927a1.33,1.33,0,0,1,0,1.883l-6.145,6.145a1.413,1.413,0,0,1-2,0h0a1.413,1.413,0,0,1,0-2Z"
                transform="translate(-8.939 -6.368)"
                fill="#9e9e9e"
              />
            </svg>
            <router-link
              to="/agencies"
              style="color: #47B362"
            >
              وكالات
            </router-link>
          </p>
        </template>
        <div class="px-md-5 px-3 mx-auto width-section mt-4">
          <h2
            class="heade-content_title"
            style="color: #636363"
            data-aos="fade-down"
            data-aos-duration="1000"
          >
            <template v-if="this.$i18n.locale == 'en'">
              Agencies
            </template>
            <template v-else-if="this.$i18n.locale == 'ar'">
              وكالات
            </template>
          </h2>
          <template v-if="this.$i18n.locale == 'en'">
            <div
              class="row no-gutters px-5"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              <div
                class="col-md-4 text-center p-4 border-mobile"
                v-for="(item, index) in Agencies"
                :key="index"
                :style="[(index != 2 && index != 5 && index != 8) ? {'border-right': '2px solid #82D998', 'border-bottom': '2px solid #82D998'} : {'border-bottom': '2px solid #82D998'}]"
              >
                <a
                  :href="item.url"
                  target="_blank"
                >
                  <img
                    :src="'images/' + item.photo.filename"
                    style="width: 60%;  object-fit: cover;"
                    alt=""
                  >
                  <h3
                    class="mt-1"
                    style="font-size: 1.1rem;  font-weight: bold; color: #222222;"
                  >{{item.name}}</h3>
                </a>
              </div>
            </div>
          </template>
          <template v-if="this.$i18n.locale == 'ar'">
            <div
              class="row no-gutters px-5"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              <div
                class="col-md-4 text-center p-4 border-mobile"
                v-for="(item, index) in Agencies"
                :key="index"
                :style="[(index != 2 && index != 5 && index != 8) ? {'border-right': '2px solid #82D998', 'border-bottom': '2px solid #82D998'} : {'border-bottom': '2px solid #82D998'}]"
              >
                <a
                  :href="item.url"
                  target="_blank"
                >
                  <img
                    :src="'images/' + item.photo.filename"
                    style="width: 60%;  object-fit: cover;"
                    alt=""
                  >
                  <h3
                    class="mt-1"
                    style="font-size: 1.1rem;  font-weight: bold; color: #222222;"
                  >{{item.name_ar}}</h3>
                </a>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: {
        about_1: "website/imgs/about_1.png",
        about_2: "website/imgs/about_2.png",
      },
      Agencies: [],
      isLoading: true,
    };
  },
  methods: {
    displayAgencies() {
      axios.get("api/webSiteAgencies").then((response) => {
        this.Agencies = response.data;
        this.isLoading = false;
      });
    },
  },
  mounted() {
    this.displayAgencies();
  },
};
</script>
