<template>
  <div>
    <div
      id="cssLoader17"
      class="main-wrap"
      v-if="isLoading"
    >
      <div class="cssLoader17"></div>
    </div>
    <div
      class="heade"
      v-if="!isLoading"
    >
      <section
        class="banner__slider position-relative"
        v-if="sliders.length"
      >
        <div class="slider stick-dots slider_header">
          <template v-if="this.$i18n.locale == 'en'">
            <div
              class="slide"
              v-for="(item, i) in sliders"
              :key="i"
            >
              <div class="slide__img ">
                <img
                  :src="'images/' + item.photo.filename "
                  alt=""
                  class="full-image animated w-100"
                  data-animation-in="zoomInImage"
                />
              </div>
              <div class="slide__content slide__content__left">
                <div class="slide__content--headings text-left">
                  <h2 class="animated title">
                    {{ item.title }}
                  </h2>
                  <p class="animated top-title">
                    {{ item.content }}
                  </p>
                </div>
              </div>
            </div>
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
            <div
              class="slide"
              v-for="item in sliders"
              :key="item.id"
            >
              <div class="slide__img ">
                <img
                  :src="'images/' + item.photo.filename "
                  alt=""
                  class="full-image animated w-100"
                  data-animation-in="zoomInImage"
                />
              </div>
              <div class="slide__content slide__content__right">
                <div class="slide__content--headings text-right">
                  <h2 class="animated title">
                    {{ item.title_ar }}
                  </h2>
                  <p class="animated top-title">
                    {{ item.content_ar }}
                  </p>
                </div>
              </div>
            </div>
          </template>

        </div>
        <div
          class=" position-absolute h-100 w-100 "
          style="top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.1);"
        ></div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          style="display: none;"
        >
          <symbol
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 44 44"
            width="44px"
            height="44px"
            id="circle"
            fill="none"
            stroke="currentColor"
          >
            <circle
              r="20"
              cy="22"
              cx="22"
              id="test"
            />
          </symbol>
        </svg>
      </section>

      <template v-if="this.$i18n.locale == 'en'">
        <div class="other_services px-md-5 px-md-4 px-2"   v-if="sections.length">
          <div class="other_services_title mx-auto">
            <h4
              data-aos="fade-down"
              data-aos-duration="1000"
            >Main Categories</h4>
          </div>
          <div
            class="banner__slider h-100 "
            style=" width: 85% "
          >
            <div
              class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              <div
                class="slide h-100 w-100 p-3"
                v-for="(item, index) in sections"
                :key="index"
              >
                <div class="vueper-slides_content">
                  <img
                    :src="'images/' + item.photo.filename"
                    alt=""
                    class="w-100 mb-3"
                    style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                  />
                  <router-link :to="'sections/' + item.id">
                    {{item.title}}
                  </router-link>
                </div>
              </div>
            </div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              style="display: none;"
            >
              <symbol
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 44 44"
                width="44px"
                height="44px"
                id="circle"
                fill="none"
                stroke="currentColor"
              >
                <circle
                  r="20"
                  cy="22"
                  cx="22"
                  id="test"
                />
              </symbol>
            </svg>
          </div>
        </div>
      </template>
      <template v-else-if="this.$i18n.locale == 'ar'">
        <div class="other_services px-md-5 px-md-4 px-2" v-if="sections.length">
          <div class="other_services_title mx-auto">
            <h4
              data-aos="fade-down"
              data-aos-duration="1000"
            >الاقسام الرئيسية</h4>
          </div>
          <div
            class="banner__slider h-100 "
            style=" width: 85% "
          >
            <div
              class="slider stick-dots slider_agriculture h-100 w-100 pr-0"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              <div
                class="slide h-100 w-100 p-3"
                v-for="(item, index) in sections"
                :key="index"
              >
                <div class="vueper-slides_content">
                  <img
                    :src="'images/' + item.photo.filename"
                    alt=""
                    class="w-100 mb-3"
                    style="height: 180px;object-fit: cover;border-radius: 5px 5px 0 0;border-bottom: 4px solid #059447;"
                  />
                  <router-link :to="'sections/' + item.id">
                    {{item.title_ar}}
                  </router-link>
                </div>
              </div>
            </div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              style="display: none;"
            >
              <symbol
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 44 44"
                width="44px"
                height="44px"
                id="circle"
                fill="none"
                stroke="currentColor"
              >
                <circle
                  r="20"
                  cy="22"
                  cx="22"
                  id="test"
                />
              </symbol>
            </svg>
          </div>
        </div>
      </template>

      <h2
        class="heade-content_title my-5"
        style="color: #636363"
        v-if="Products.length"
        data-aos="fade-down"
        data-aos-duration="1000"
      >
        <template v-if="this.$i18n.locale == 'en'">
          Our <span style="color: #47B362">Products</span>
        </template>
        <template v-else-if="this.$i18n.locale == 'ar'">
          منتجاتنا
        </template>
      </h2>
      <template v-if="this.$i18n.locale == 'en'">
        <div
          class="row no-gutters px-md-0 px-3"
          v-if="Products.length"
          data-aos="fade-up"
          data-aos-duration="1000"
        >
          <div class="col-md-10 ml-auto">
            <div class="banner__slider h-100 w-100">
              <div class="slider stick-dots our_products h-100 w-100 pr-0">
                <div
                  class="slide h-100 w-100"
                  v-for="(item, i) in Products"
                  :key="i"
                  v-if="(i < 5)"
                >
                  <div
                    class="vueper-slides_content position-relative "
                    :style="{
                            'background-image': `url(${'images/'+ item.photo.filename})`
                        }"
                    style="height: 360px;border-radius: 5px 0px 0px 5px;background-position: center;background-repeat: no-repeat;background-size: cover;"
                  >
                    <div
                      class="position-absolute h-100 p-4 text-left  p-mobile"
                      style="width: 30%;background-color: #066632;right: 5%;"
                    >
                      <h3 class="text-white">{{item.title}}</h3>
                      <p class="text-white"> {{
                                            item.content
                                                .split(" ")
                                                .filter((e, i) => i < 20)
                                                .join(" ") + "..."
                                        }}</p>

                    </div>
                  </div>
                </div>
              </div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style="display: none;"
              >
                <symbol
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 44 44"
                  width="44px"
                  height="44px"
                  id="circle"
                  fill="none"
                  stroke="currentColor"
                >
                  <circle
                    r="20"
                    cy="22"
                    cx="22"
                    id="test"
                  />
                </symbol>
              </svg>
            </div>
          </div>
        </div>
      </template>
      <template v-else-if="this.$i18n.locale == 'ar'">
        <div
          class="row no-gutters px-md-0 px-3"
          v-if="Products.length"
          data-aos="fade-up"
          data-aos-duration="1000"
        >
          <div class="col-md-10 ml-auto">
            <div class="banner__slider h-100 w-100">
              <div class="slider stick-dots our_products h-100 w-100 pr-0">
                <div
                  class="slide h-100 w-100"
                  v-for="(item, i) in Products"
                  :key="i"
                  v-if="(i < 5)"
                >
                  <div
                    class="vueper-slides_content position-relative"
                    :style="{
                            'background-image': `url(${'images/'+ item.photo.filename})`
                        }"
                    style="height: 360px;border-radius: 5px 0px 0px 5px;background-position: center;background-repeat: no-repeat;background-size: cover;"
                  >
                    <div
                      class="position-absolute h-100 p-4 text-right p-mobile"
                      style="width: 30%;background-color: #066632;right: 5%;"
                    >
                      <h3 class="text-white">{{item.title_ar}}</h3>
                      <p class="text-white"> {{
                                            item.content_ar
                                                .split(" ")
                                                .filter((e, i) => i < 20)
                                                .join(" ") + "..."
                                        }}</p>

                    </div>
                  </div>
                </div>
              </div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                style="display: none;"
              >
                <symbol
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 44 44"
                  width="44px"
                  height="44px"
                  id="circle"
                  fill="none"
                  stroke="currentColor"
                >
                  <circle
                    r="20"
                    cy="22"
                    cx="22"
                    id="test"
                  />
                </symbol>
              </svg>
            </div>
          </div>
        </div>
      </template>
      <div
        class="px-md-0 px-3 mx-auto pb-md-5 mb-0 width-section position-relative"
        style="margin-top: 8%;"
        v-if="aboutUs.length"

      >
        <h2
          class="heade-content_title"
          style="color: #636363"
        >
          <template v-if="this.$i18n.locale == 'en'">
            About <span style="color: #47B362">Us</span>
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
            من <span style="color: #47B362">نحن</span>
          </template>
        </h2>

        <template v-if="this.$i18n.locale == 'en'">
          <div
            class="row no-gutters about-left"
            v-for="(item, i) in aboutUs"
            :key="i"
            v-if="i == 0"
          >
            <div class="col-md-10 my-5 position-relative">
              <img
                :src="'images/' + item.photo.filename"
                width="100%"
                style="height: 350px;object-fit: cover; "
              />
              <div class="w-100 about-div-img">
                <div class="about-div-img-content p-3 pb-5">
                  <h4 class="donate_title mx-md-2 text-center">
                    {{ item.title }}
                  </h4>
                  <p
                    class="donate-text mx-md-2 mt-4"
                    style="color:#D0F5D9"
                  >
                    {{ item.content }}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <router-link
            to="/about-us"
            class="url_more mt-4"
            style="right: 17%; bottom: auto; color: #059447; font-weight: bold; font-size: 1rem;"
          >
            Read More About Us
            <img
              :src="images.right"
              width="25px"
              class="ml-2"
              style=" object-fit: cover "
            />
          </router-link>
        </template>
        <template v-else-if="this.$i18n.locale == 'ar'">
          <div
            class="row no-gutters  about-right"
            v-for="(item, i) in aboutUs"
            :key="i"
            v-show="i == 0"
          >
            <div class="col-md-10 my-5 position-relative">
              <img
                :src="'images/' + item.photo.filename"
                width="100%"
                style="height: 350px;object-fit: cover; "
              />
              <div class="w-100 about-div-img">
                <div class="about-div-img-content p-3 pb-5">
                  <h4 class="donate_title mx-md-2 text-center">
                    {{ item.title_ar }}
                  </h4>
                  <p
                    class="donate-text mx-md-2 mt-4 text-right"
                    style="color:#D0F5D9"
                  >
                    {{ item.content_ar }}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <router-link
            to="/about-us"
            class="url_more mt-4"
            style="left: 17%!important; bottom: auto!important; color: #059447; font-weight: bold; font-size: 1rem;"
          >
            <img
              :src="images.right"
              width="25px"
              class="mr-2"
              style="object-fit: cover;transform: rotate(180deg);"
            />
            اقرأ المزيد عنا

          </router-link>
        </template>

      </div>

      <div
        class="px-md-0 px-3 mx-auto pb-5 width-section mt-md-4 mt-5"
        v-if="News.length"
      >
        <h2
          class="heade-content_title"
          style="color: #636363"
        >
          <template v-if="this.$i18n.locale == 'en'">
            News
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
            الاخبار
          </template>
        </h2>
        <div class="row no-gutters my-5 px-4 position-relative">

          <template v-if="this.$i18n.locale == 'en'">
            <div
              class="col-md-7 p-3"
              v-for="(item, i) in News"
              :key="i"
              v-if="i == 0"
            >
              <div
                class="w-100 row no-gutters h-mobile"
                style="border-radius: 8px; background-color: #EDFAF1; height: 400px;"
              >
                <div class="col-12 h-100">
                  <img
                    class="card-img-top h-100"
                    :src="'images/' + item.photo.filename"
                    width="100%"
                    style="border-radius: 8px;  object-fit: cover "
                  />
                </div>

                <div class="text-left p-3 col-12">
                  <h5 class="card-title mb-0">
                    {{
                                            item.title
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                  </h5>
                  <p class="card-text mt-2">
                    {{
                                            item.leadingParagraph
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                  </p>
                  <router-link
                    :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                    class="url_more "
                  >
                    Read more
                    <img
                      :src="images.right"
                      width="25px"
                      class="ml-2"
                      style=" object-fit: cover "
                    />
                  </router-link>
                </div>
              </div>

            </div>
            <div class="col-md-5 p-3">
              <div
                class="w-100 row no-gutters mb-3 h-mobile"
                v-for="(item, i) in News"
                :key="i"
                v-if="(i != 0) && (i < 4)"
                style="border-radius: 8px; background-color: #EDFAF1; height: 170px;"
              >
                <div class="col-md-4 h-100">
                  <img
                    class="card-img-top h-100"
                    :src="'images/' + item.photo.filename"
                    width="100%"
                    style="border-radius: 8px 0 0 8px ;  object-fit: cover "
                  />
                </div>

                <div class="text-left p-3 col-md-8">
                  <h5 class="card-title mb-0">
                    {{
                                            item.title
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                  </h5>
                  <p class="card-text mt-2">
                    {{
                                            item.leadingParagraph
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                  </p>
                  <router-link
                    :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                    class="url_more "
                  >
                    Read more
                    <img
                      :src="images.right"
                      width="25px"
                      class="ml-2"
                      style=" object-fit: cover "
                    />
                  </router-link>
                </div>
              </div>
            </div>
            <router-link
              to="/news"
              class="url_more mt-4"
              style="right: 3%!important; bottom: -5%!important; color: #059447; font-weight: bold; font-size: 1rem;"
            >
              Read More News
              <img
                :src="images.right"
                width="25px"
                class="ml-2"
                style=" object-fit: cover "
              />
            </router-link>
          </template>
          <template v-if="this.$i18n.locale == 'ar'">

            <div class="col-md-5 p-3">
              <div
                class="w-100 row no-gutters mb-3 h-mobile"
                v-for="(item, i) in News"
                :key="i"
                v-if="(i != 0) && (i < 4)"
                style="border-radius: 8px; background-color: #EDFAF1; height: 170px;"
              >
                <div class="text-left p-3 col-md-8 order-md-1 order-2">
                  <h5
                    class="card-title mb-0 text-right"
                    dir="rtl"
                  >
                    {{
                                            item.title_ar
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                  </h5>
                  <p
                    class="card-text mt-2 text-right"
                    dir="rtl"
                  >
                    {{
                                            item.leadingParagraph_ar
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                  </p>
                  <router-link
                    :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                    class="url_more "
                    style="left: 15px;right: auto;"
                  >
                    <img
                      :src="images.right"
                      width="25px"
                      class="mr-2"
                      style="object-fit: cover;transform: rotate(180deg);"
                    />
                    اقرأ أكثر
                  </router-link>
                </div>
                <div class="col-md-4 h-100 order-md-2 order-1">
                  <img
                    class="card-img-top h-100"
                    :src="'images/' + item.photo.filename"
                    width="100%"
                    style="border-radius:  0 8px 8px 0 ;  object-fit: cover "
                  />
                </div>

              </div>
            </div>
            <div
              class="col-md-7 p-3"
              v-for="(item, i) in News"
              :key="i"
              v-if="i == 0"
            >
              <div
                class="w-100 row no-gutters h-mobile"
                style="border-radius: 8px; background-color: #EDFAF1; height: 400px;"
              >
                <div class="col-12 h-100">
                  <img
                    class="card-img-top h-100"
                    :src="'images/' + item.photo.filename"
                    width="100%"
                    style="border-radius: 8px;  object-fit: cover "
                  />
                </div>

                <div class="text-left p-3 col-12">
                  <h5
                    class="card-title mb-0 text-right"
                    dir="rtl"
                  >
                    {{
                                            item.title_ar
                                                .split(" ")
                                                .filter((e, i) => i < 3)
                                                .join(" ") + "..."
                                        }}
                  </h5>
                  <p
                    class="card-text mt-2 text-right"
                    dir="rtl"
                  >
                    {{
                                            item.leadingParagraph_ar
                                                .split(" ")
                                                .filter((e, i) => i < 12)
                                                .join(" ") + "..."
                                        }}
                  </p>
                  <router-link
                    :to="
                                            '/news/new-details/' +
                                                item.id
                                        "
                    class="url_more "
                    style="left: 15px;right: auto;"
                  >
                    <img
                      :src="images.right"
                      width="25px"
                      class="mr-2"
                      style="object-fit: cover;transform: rotate(180deg);"
                    />
                    اقرأ أكثر
                  </router-link>
                </div>
              </div>

            </div>
            <router-link
              to="/news"
              class="url_more mt-4"
              style="left: 3%!important; bottom: -5%!important; color: #059447; font-weight: bold; font-size: 1rem;"
            >
              <img
                :src="images.right"
                width="25px"
                class="ml-2"
                style="object-fit: cover;transform: rotate(180deg);"
              />
              اقرأ المزيد من الاخبار
            </router-link>
          </template>
        </div>
      </div>

      <div
        class="px-md-5 px-3 mx-auto width-section mt-4"
        v-if="Agencies.length"
      >
        <h2
          class="heade-content_title"
          style="color: #636363"
        >
          <template v-if="this.$i18n.locale == 'en'">
            Agencies
          </template>
          <template v-else-if="this.$i18n.locale == 'ar'">
            وكالات
          </template>
        </h2>
        <template v-if="this.$i18n.locale == 'en'">
          <div class="row no-gutters px-5">
            <div
              class="col-md-4 text-center p-4  border-mobile"
              v-for="(item, index) in Agencies"
              :key="index"
              v-if="(index < 3)"
              :style="[(index != 2 && index != 5 && index != 8) ? {'border-right': '2px solid #82D998'} : '']"
            >
              <a
                :href="item.url"
                target="_blank"
              >
                <img
                  :src="'images/' + item.photo.filename"
                  style="width: 60%;  object-fit: cover;"
                  alt=""
                >
                <h3
                  class="mt-1"
                  style="font-size: 1.1rem;  font-weight: bold; color: #222222;"
                >{{item.name}}</h3>
              </a>
            </div>
          </div>
        </template>
        <template v-if="this.$i18n.locale == 'ar'">
          <div class="row no-gutters px-5">
            <div
              class="col-md-4 text-center p-4  border-mobile"
              v-for="(item, index) in Agencies"
              :key="index"
              v-if="(index < 3)"
              :style="[(index != 2 && index != 5 && index != 8) ? {'border-right': '2px solid #82D998'} : '']"
            >
              <a
                :href="item.url"
                target="_blank"
              >
                <img
                  :src="'images/' + item.photo.filename"
                  style="width: 60%;  object-fit: cover;"
                  alt=""
                >
                <h3
                  class="mt-1"
                  style="font-size: 1.1rem;  font-weight: bold; color: #222222;"
                >{{item.name_ar}}</h3>
              </a>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  data() {
    return {
      images: {
        download: "website/imgs/download.svg",
        right: "website/imgs/chevron-right-solid.svg",
        circle_1: "website/imgs/circle-1.svg",
        circle_2: "website/imgs/circle-2.svg",
      },
      isLoading: true,
      sliders: [],
      aboutUs: [],
      News: [],
      Agencies: [],
      Products: [],
      sections: [],
    };
  },
  methods: {
    displaySections() {
      axios.get("api/sections").then((response) => {
        this.sections = response.data;
      });
    },
    displaySlider() {
      axios.get("api/webSiteImageslide").then((response) => {
        this.sliders = response.data;
      });
    },
    displayAboutUs() {
      axios.get("api/webSiteAboutUs").then((response) => {
        this.aboutUs = response.data;
      });
    },
    displayNews() {
      axios.get("api/webSiteNews").then((response) => {
        this.News = response.data;
      });
    },
    displayAgencies() {
      axios.get("api/webSiteAgencies").then((response) => {
        this.Agencies = response.data;
      });
    },
    displayProducts() {
      axios.get("api/last-products").then((response) => {
        this.Products = response.data;
        setTimeout(() => {
          this.isLoading = false;
        }, 2000);
      });
    },
    uploadData() {
      this.displaySections();
      this.displaySlider();
      this.displayAboutUs();
      this.displayNews();
      this.displayAgencies();
      this.displayProducts();
    },
  },
  mounted() {
    this.uploadData();
  },
  computed: {},
};
</script>
