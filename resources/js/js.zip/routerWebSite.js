import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)


// Website Router
import websiteIndex from './components/website/home/index.vue'
import websiteAboutUs from './components/website/About_Us/index.vue'
import websiteNews from './components/website/News/index.vue'
import websiteNewDetails from './components/website/News/view.vue'
import websiteSections from './components/website/Sections/index.vue'
import websiteProductsDetails from './components/website/Sections/view.vue'


// import websiteAgriculture from './components/website/Agriculture/index.vue'
// import websiteAgricultureDetails from './components/website/Agriculture/view.vue'
// import websiteFood_Staff from './components/website/Food_Staff/index.vue'
// import websiteFood_StaffDetails from './components/website/Food_Staff/view.vue'
// import websiteRenewable_Energy from './components/website/Renewable_Energy/index.vue'
// import websiteRenewable_EnergyDetails from './components/website/Renewable_Energy/view.vue'
// import websiteOthers from './components/website/Others/index.vue'
// import websiteOthersDetails from './components/website/Others/view.vue'

import websiteAgencies from './components/website/Agencies/index.vue'
import websitePartnership from './components/website/Partnership/index.vue'

import websiteGallery from './components/website/Gallery/index.vue'

import websiteContactUs from './components/website/Contact_Us/index.vue'

import websiteBranches from './components/website/Branches/index.vue'
const routes = [

    // Website Router
    {
		path: '/',
        component: websiteIndex,
        name: 'home'
    },
    {
		path: '/about-us',
		component: websiteAboutUs
    },
    {
		path: '/news',
		component: websiteNews
    },
    {
		path: '/news/new-details/:id',
		component: websiteNewDetails
    },

    {
		path: '/sections/:id',
		component: websiteSections
    },
    {
		path: '/product/details/:id',
		component: websiteProductsDetails
    },






    // {
	// 	path: '/agriculture',
	// 	component: websiteAgriculture
    // },
    // {
	// 	path: '/agriculture/details/:id',
	// 	component: websiteAgricultureDetails
    // },
    // {
	// 	path: '/food-staff',
	// 	component: websiteFood_Staff
    // },
    // {
	// 	path: '/food-staff/details/:id',
	// 	component: websiteFood_StaffDetails
    // },
    // {
	// 	path: '/renewable-energy',
	// 	component: websiteRenewable_Energy
    // },
    // {
	// 	path: '/renewable-energy/details/:id',
	// 	component: websiteRenewable_EnergyDetails
    // },
    // {
	// 	path: '/others',
	// 	component: websiteOthers
    // },
    // {
	// 	path: '/others/details/:id',
	// 	component: websiteOthersDetails
    // },
    {
		path: '/agencies',
		component: websiteAgencies
    },
    {
		path: '/partnership',
		component: websitePartnership
    },
    {
		path: '/gallery',
		component: websiteGallery
    },
    {
		path: '/contact-us',
		component: websiteContactUs
    },
    {
		path: '/branches',
		component: websiteBranches
    },

]


export default new Router({
	mode: 'history',
	routes
})
